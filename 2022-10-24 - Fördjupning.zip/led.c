/********************************************************************************
* led.c: Funktionsdefinitioner f�r styrning av lysdioderna.
********************************************************************************/
#include "header.h"

/* Statiska variabler: */
static bool led1_enabled = false; /* Indikerar ifall lysdiod 1 �r aktiverad. */
static bool led2_enabled = false; /* Indikerar ifall lysdiod 2 �r aktiverad. */
static uint16_t blink_speed = 0;  /* Lysdiodernas blinkhastighet i millisekunder. */

/* Statiska funktioner: */
static void toggle(bool* enabled, 
                   const uint8_t pin);
static void delay_ms(const volatile uint16_t* delay_time_ms);

/********************************************************************************
* led_toggle: Togglar lysdiod p� I/O-port B mellan att vara t�nd eller sl�ckt.
*             Ifall b�da lysdioder �r inaktiverade efter togglingen nollst�lls
*             variabeln som lagrar blinkhastigheten f�r att direkt avbryta
*             eventuell blinkning.
*
*             - pin: Lysdiodens pin-nummer p� I/O-port B.
********************************************************************************/
void led_toggle(const uint8_t pin)
{
   if (pin == LED1)
   {
      toggle(&led1_enabled, LED1);
   }
   else if (pin == LED2)
   {
      toggle(&led2_enabled, LED2);
   }

   if (!led1_enabled && !led2_enabled) blink_speed = 0;
   return;
}

/********************************************************************************
* led_blink: Blinkar aktiverade lysdioder p� I/O-port B i en slinga med angiven
*            blinkhastighet.
*
*            - pin: blink_speed_ms: Blinkhastigheten m�tt i millisekunder.
********************************************************************************/
void led_blink(const uint16_t blink_speed_ms)
{
   blink_speed = blink_speed_ms;

   if (led1_enabled && !led2_enabled)
   {
      LED1_ON;
      delay_ms(&blink_speed);
      LED1_OFF;
      delay_ms(&blink_speed);
   }
   else if (!led1_enabled && led2_enabled)
   {
      LED2_ON;
      delay_ms(&blink_speed);
      LED2_OFF;
      delay_ms(&blink_speed);
   }   
   else if (led1_enabled && led2_enabled)
   {
      LED1_ON;
      delay_ms(&blink_speed);
      LED1_OFF;
      LED2_ON;
      delay_ms(&blink_speed);
      LED2_OFF;
   }

   LEDS_OFF;
   return;
}

/********************************************************************************
* toggle: Togglar lysdiod p� I/O-port B mellan att vara t�nd eller sl�ckt.
*         Refererad enable-variabel togglas, d�r det nya v�rdet (true/false) 
*         avg�r ifall lysdioden skall t�ndas eller sl�ckas. Angivet pin-nummer
*         anv�nds f�r att t�nda eller sl�cka lysdioden p� I/O-port B.
*
*             - enabled: Pekare till variabel som lagrar lysdiodens tillst�nd.
*             - pin    : Lysdiodens pin-nummer p� I/O-port B.
********************************************************************************/
static void toggle(bool* enabled, 
                   const uint8_t pin)
{
   *enabled = !(*enabled);
   if (enabled) PORTB |= (1 << pin);
   else PORTB &= ~(1 << pin);
   return;
}

/********************************************************************************
* delay_ms: Genererar f�rdr�jning m�tt i millisekunder.
*
*           - delay_time_ms: Pekare till minnesadress inneh�llande angiven
*                            f�rdr�jningstid i millisekunder.
********************************************************************************/
static void delay_ms(const volatile uint16_t* delay_time_ms)
{
   for (uint16_t i = 0; i < *delay_time_ms; ++i)
   {
      _delay_ms(1);
   }
   return;
}