/********************************************************************************
* main.c: Implementering av ett inbyggt system inneh�llande tv� lysdioder
*         anslutna till pin 8 - 9 (PORTB0 - PORTB1) samt tv� tryckknappar
*         anslutna till pin 2 - 3 (PORTB2 - PORTB3). Externa avbrott INT0 - INT1
*         aktiveras p� tryckknapparnas pinnar f�r att toggla en given lysdiod.
*
*         Vid nedtryckning av tryckknappen BUTTON1 ansluten till pin 2 togglas
*         lysdioden LED1 ansluten till pin 8. Vid uppsl�ppning av tryckknappen
*         BUTTON2 ansluten till pin 3 togglas lysdioden LED2 ansluten till
*         pin 9. Aktiverade lysdioder blinkar var 100:e millisekund.
********************************************************************************/
#include "header.h"

/********************************************************************************
* main: Initierar mikrodatorn vid start. Aktiverade lysdioder blinkar sedan
*       var 100:e millisekund.
********************************************************************************/
int main(void)
{
   setup();

   while (1)
   {
      led_blink(100);
   }

   return 0;
}

